# Whiskers: Legend of the Celestial Blossom

## 1. Executive Summary
**Whiskers: Legend of the Celestial Blossom** is an epic 8-level 3D action-adventure mobile game developed with Unity / Flutter for Android. Players control **Milo**, an agile, sword-wielding cat warrior on a quest across 8 diverse realms where **each level requires achieving a specific key quest item or objective** to eventually cure his beloved master from a mortal curse.

---

## 2. Core Game Loop & Features
- **Genre:** 3D Action-Adventure / Hack-and-Slash
- **Hero:** Milo the Cat Warrior
- **Perspective:** Third-Person 3D Camera
- **Target Platform:** Mobile (Android)
- **Controls:** Virtual Joystick + Max 4 Action Buttons
- **Business Model:** Free-to-Play full 8-level campaign with optional cosmetic and quality-of-life In-App Purchases (IAP)

---

## 3. Game Story Premise & Connected Quest Chain
Master Sifu collapses in his dojo from a mysterious dark illness. Milo must complete a chain of 8 connected level achievements—finding a doctor, retrieving an ancient book, obtaining a solar lens, forging a thermal flask, learning the recipe from a spirit alchemist, claiming the sky key, projecting a starlight bridge, and harvesting the flower to cure his master.

---

## 4. Master Level Achievement Chain

| Level | Environment | Key Objective / Achievement |
| :--- | :--- | :--- |
| **Level 1** | Dojo & City Suburbs | 👨‍⚕️ **Find the Village Doctor:** Diagnoses the Shadow Curse & reveals the existence of an ancient book. |
| **Level 2** | Whispering Jungle | 📖 **Find the Ancient Botanical Book:** Contains the lore of the Celestial Blossom (written in invisible solar ink). |
| **Level 3** | Sunken Desert Ruins | 🔍 **Retrieve the Solar Crystal Lens:** Reveals the hidden map & warns that the flower needs a special flask. |
| **Level 4** | Crystal Caverns | 🧪 **Forge the Thermal Crystal Flask:** Forged in volcanic heat to preserve the flower without withering. |
| **Level 5** | Haunted Swamps | 👻 **Consult the Spirit Alchemist:** Teaches Milo the exact Celestial Brew Recipe & de-curse ritual. |
| **Level 6** | Misty Mountains | 🔑 **Claim the Celestial Sky Key:** Won in a noble duel against Milo's rival Kuro. |
| **Level 7** | Sky Citadel | 🌌 **Align the Star Telescope:** Projects the solid Golden Starlight Bridge across the clouds. |
| **Level 8** | Celestial Garden | 🌸 **Defeat Umbra & Harvest the Flower:** Binds the blossom in the flask, returns home, and cures Master Sifu! |

---

## 5. On-Screen Controls (Mobile Max 4-Button Scheme)

```
+-------------------------------------------------------+
| [ Health Bar ❤️❤️❤️ ]                 [ Level 1-1 ]    |
|                                                       |
|                  [ 3D CAMERA VIEW ]                   |
|                                                       |
|   [ 🕹️ JOYSTICK ]              [ 🛡️ DODGE ] [ ⚔️ SLASH ] |
|   (Move / Turn)                 [ 🍶 POTION] [ 💥 HEAVY ] |
+-------------------------------------------------------+
```

1. **Virtual Joystick (Bottom Left):** Smooth 360-degree 3D character movement and directional orientation.
2. **Button 1 — ⚔️ Sword Slash (Light Attack):** Rapid taps perform 3-hit sword combo attacks.
3. **Button 2 — 💥 Heavy Attack / Pounce:** Charged attack that breaks enemy shields and wooden barricades.
4. **Button 3 — 🛡️ Dodge Roll / Evade:** Fast evasion maneuver with temporary invulnerability frames.
5. **Button 4 — 🍶 Healing Potion:** Consumes a collected Milk/Catnip potion to restore Milo's health bar.

---

## 6. Monetization & In-App Purchases (IAP)
The core 8-level campaign story is **100% free to play**. Players can optionally purchase premium items in the in-game store:

### A. Weapon Skins
- **Flame Katana:** Leaves trailing fire particle effects during slashes.
- **Lightning Rapier:** Emits electric arcs upon strike.
- **Wooden Training Sword:** High-speed fun aesthetic skin.

### B. Character Armor Outfits
- **Samurai Milo:** Traditional golden samurai armor and helmet.
- **Shadow Ninja:** Sleek dark stealth suit with a red cape.
- **Royal Knight Armor:** Silver polished plate armor.

### C. Convenience & Boosters
- **Remove Ads:** One-time permanent ad removal.
- **Infinite Health Potions Pack:** Convenience refill booster.
- **2x Coin Multiplier:** Permanent boost to treat/coin collection rates.
