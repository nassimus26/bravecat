# Level 5: The Haunted Swamps & Ghost Village

## 1. Setting & Atmosphere
- **Environment:** Eerie mist-shrouded wetlands, giant weeping willow trees, an abandoned wooden village on stilts, floating glowing will-o'-the-wisps, paper lanterns, and dark swamp waters.
- **Time of Day:** Midnight / Full Moon.
- **Music & Audio:** Haunting erhu string melodies, croaking frogs, night crickets, ghostly whispers, and splashing water.

---

## 2. Narrative Scenario
Milo arrives in the Haunted Swamps to seek out **Master Botan**, the spirit of an ancient legendary feline alchemist who knows the exact brewing recipe to cleanse the Shadow Curse.

---

## 3. Level Quest Objective: 👻 Consult Master Botan (The Spirit Alchemist)
- **Primary Goal:** Purify the 4 Spirit Lanterns in the abandoned village to summon the spirit of Master Botan.
- **Key Achievement:** Master Botan teaches Milo the **Celestial Brew Recipe & Ritual**.
- **Alchemist's Recipe:**
  > *"Listen closely, young blade! The flower alone cannot cure the curse if prepared incorrectly. You must steep 3 petals in boiled spring water at dawn, stir counter-clockwise three times, and chant the Mantra of Light while feeding it to your master!"*

---

## 4. Environment Mechanics & Hazards
- **Lantern Light Safe-Zones:** Dark miasma drains Milo's health over time. Milo must stay within glowing paper lantern light.
- **Floating Lotus Leaf Jumping:** Giant lotus leaves float on dark swamp waters; stepping on them causes them to slowly sink.
- **Spectral Bridges:** Ghostly blue bridges that become solid only when illuminated by spirit lanterns.

---

## 5. Enemies Introduced
- **Phantom Spectral Cats:** Ghostly feline warriors armed with ethereal rapiers.
- **Poison Mire Frogs:** Giant frogs that leap from the mud and tongue-grab Milo.
- **Will-o'-the-Wisps:** Floating fiery spirits that explode upon close contact.

---

## 6. Boss Fight: "Yurei the Phantom Empress"
- **Location:** The Spirit Pavilion Altar.
- **Description:** An ethereal feline ghost queen corrupted by shadow energy blocking access to Master Botan's shrine.
- **Reward:** Yurei is purified, granting Milo an audience with **Master Botan**.

---

## 7. Level Ending & Reward
With the **Celestial Brew Recipe** memorized, Milo heads toward the icy cliffs of the **Misty Mountains** to find the portal leading into the sky.
