# Level 7: The Sky Citadel & Ancient Observatories

## 1. Setting & Atmosphere
- **Environment:** An ancient brass-and-marble floating fortress perched above the clouds, giant spinning clockwork gears, star observatories, brass telescope platforms, and lightning-rod spires.
- **Time of Day:** Sunset / Golden Hour above the clouds.
- **Music & Audio:** Majestic brass fanfares, ticking clockwork mechanisms, electric hums, and sweeping wind currents.

---

## 2. Narrative Scenario
Milo arrives in the floating **Sky Citadel**. To cross the void of space to the floating Celestial Garden, Milo must re-align the citadel's Great Star Telescope to project a solid bridge of golden starlight.

---

## 3. Level Quest Objective: 🌌 Align the Star Telescope & Project the Starlight Bridge
- **Primary Goal:** Re-align the 3 Grand Astrolabe Gears and defeat Orion the Clockwork Sentinel to power the Star Telescope.
- **Key Achievement:** The Star Telescope fires a beam of concentrated starlight, forming the **Golden Starlight Bridge** leading directly to the Celestial Altar!

---

## 4. Environment Mechanics & Hazards
- **Rotating Clockwork Gears:** Giant vertical and horizontal gears that Milo must jump across.
- **Gravity Inversion Tiles:** Special glowing floor pads that flip gravity, allowing Milo to walk on ceiling walkways.
- **Electric Arc Conduits:** Periodic high-voltage electrical arcs discharging between brass spires.

---

## 5. Enemies Introduced
- **Clockwork Brass Sentinels:** Mechanical warriors armed with shield-halberds.
- **Gargoyle Guardians:** Stone-and-brass flying sentries that drop clockwork bombs.
- **Arc Turrets:** Automated wall turrets firing tracking energy bolts.

---

## 6. Boss Fight: "Orion the Clockwork Sentinel"
- **Location:** The Great Telescope Dome.
- **Description:** A colossal 20-foot tall brass knight wielding a giant sword and tower shield.
- **Reward:** Orion deactivates, focusing the starlight beam through the telescope to project the bridge.

---

## 7. Level Ending & Reward
Milo steps onto the solid **Golden Starlight Bridge** and marches toward his final destination—the **Celestial Garden**!
