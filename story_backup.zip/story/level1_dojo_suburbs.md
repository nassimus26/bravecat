# Level 1: The Dojo & City Suburbs

## 1. Setting & Atmosphere
- **Environment:** A tranquil Asian-inspired suburban village featuring traditional wooden dojos, pink cherry blossom trees, stone lanterns, tiled roofs, and bamboo fences.
- **Time of Day:** Early Morning (Golden Sunrise).
- **Music & Audio:** Calming acoustic shamisen and flute music that gradually builds in tension when enemies approach.

---

## 2. Narrative Scenario & Opening Cutscene
Master Sifu collapses in the courtyard of his dojo, coughing up dark shadow mist. Milo rushes to his side, but Master Sifu is unresponsive. Milo draws his family katana and carries Master Sifu into the village.

---

## 3. Level Quest Objective: 👨‍⚕️ Find Dr. Whiskerfield (The Village Doctor)
- **Primary Goal:** Traverse the suburb streets past corrupted alley rats and hounds to reach **Dr. Whiskerfield's Medical Clinic**.
- **Key Achievement:** Dr. Whiskerfield examines Master Sifu and identifies the affliction as the ancient **Shadow Curse**.
- **Doctor's Clue:** 
  > *"This dark curse cannot be cured by ordinary medicine! Legend speaks of the Celestial Blossom on Sky Peak, but its secrets are recorded in an Ancient Botanical Tome hidden in the Jungle Sanctuary. Take my medical pass and find that book!"*

---

## 4. Gameplay Mechanics & Tutorial Flow
1. **Movement Tutorial:** Use the Virtual Joystick to walk through the dojo bamboo garden.
2. **Combat Tutorial:** Attack wooden training dummies using the **⚔️ Slash Button** (3-hit light combo).
3. **Evasion Tutorial:** Use the **🛡️ Dodge Roll Button** to roll under fallen wooden carts blocking the street.
4. **Pounce Tutorial:** Use the **💥 Heavy Attack Button** to break locked crates containing Milo's first **🍶 Healing Milk Potion**.

---

## 5. Enemies Introduced
- **Training Dummies:** Stationary targets for basic mechanics.
- **Corrupted Alley Rats:** Basic melee enemies armed with tiny wooden clubs. Low health (2 light slashes to defeat).
- **Stray Hounds:** Fast charging enemies that telegraph attacks before lunging. Requires dodging before counter-attacking.

---

## 6. Mini-Boss Fight: "Grimfang the Alley King"
- **Location:** The Clinic Plaza Gate.
- **Description:** A large, scar-faced alley rat guarding the clinic entrance with a heavy spiked pipe.
- **Reward:** Grimfang drops the **Clinic Gate Key**.

---

## 7. Level Ending & Reward
Milo enters the clinic, receives Dr. Whiskerfield's diagnosis and medical pass, and steps out toward the gates of the **Whispering Jungle** to find the Ancient Botanical Tome!
