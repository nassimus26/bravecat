# Level 4: The Crystal Caverns & Lava Chasms

## 1. Setting & Atmosphere
- **Environment:** Subterranean caverns lined with glowing blue/purple quartz crystals, rivers of bubbling molten lava, basalt rock arches, and shimmering heat distortion.
- **Time of Day:** Deep Subterranean / Volcanic Glow.
- **Music & Audio:** Deep bass reverberations, dripping water, roaring lava flows, and metallic sword impacts.

---

## 2. Narrative Scenario
To safely carry the Celestial Blossom home without it withering, Milo must forge a **Thermal Crystal Flask** using rare volcanic quartz and extreme geothermal heat.

---

## 3. Level Quest Objective: 🧪 Forge the Thermal Crystal Flask
- **Primary Goal:** Gather 3 Raw Vulcan Quartz Crystals and use the heat of the Magma Drake's forge chamber to forge the vessel.
- **Key Achievement:** Milo successfully crafts the unbreakable **Thermal Crystal Flask**!
- **Flask Property:**
  > Capable of storing the Celestial Blossom in stasis indefinitely without losing its divine curative power.

---

## 4. Environment Mechanics & Hazards
- **Crystal Prism Light Puzzles:** Milo strikes reflective quartz prisms to rotate them and bounce energy beams onto forge altars.
- **Lava Geysers:** Geysers erupt periodically from molten rivers.
- **Cracking Basalt Platforms:** Volcanic rock stepping stones that crumble 3 seconds after being stepped on.

---

## 5. Enemies Introduced
- **Magma Bats:** Swarming fiery bats that dive-bomb Milo.
- **Crystal Golems:** Heavy stone constructs with quartz armor. Requires Heavy Pounce Attacks.
- **Fire Elementals:** Ranged enemies that hurl fiery orbs.

---

## 6. Boss Fight: "Ignis the Magma Drake"
- **Location:** The Volcanic Forge Chamber.
- **Description:** A fearsome dragon-lizard dripping with molten magma guarding the natural thermal forge.
- **Reward:** Ignis's defeat activates the thermal forge, combining Milo's quartz crystals into the **Thermal Crystal Flask**.

---

## 7. Level Ending & Reward
With the Thermal Crystal Flask equipped at his hip, Milo now needs the exact **brew recipe and ritual** to prepare the flower once harvested. He ascends toward the **Haunted Swamps** to consult the Spirit Alchemist.
