# Level 6: The Misty Mountain Crags & Glacier Pass

## 1. Setting & Atmosphere
- **Environment:** Freezing mountain cliffs, howling blizzard winds, icy narrow paths, frozen waterfalls, suspended wooden rope bridges, and ancient shrine gates.
- **Time of Day:** Twilight / Howling Blizzard.
- **Music & Audio:** Epic orchestral strings, blowing wind audio, clashing metal blades, and crunching snow steps.

---

## 2. Narrative Scenario
Ascending past the ghost village, Milo reaches the snow-covered **Misty Mountain Crags**. Standing before the Sky Portal is **Kuro**, a rogue samurai cat and Master Sifu's former senior student, who holds the **Celestial Sky Key**.

---

## 3. Level Quest Objective: 🔑 Claim the Celestial Sky Key
- **Primary Goal:** Climb the blizzard cliffs and prove your strength to Kuro in a honorable sword duel.
- **Key Achievement:** Kuro surrenders the **Celestial Sky Key** to Milo!
- **Kuro's Words:**
  > *"You have the heart of a true warrior, Milo... Master Sifu chose his successor well. Take the Sky Key and unlock the portal to the Sky Citadel!"*

---

## 4. Environment Mechanics & Hazards
- **Slippery Ice Surfaces:** Movement on icy paths has momentum sliding.
- **Ice Stalactites:** Icicles falling from cliff overhangs when Milo runs underneath.
- **Gale Winds:** Strong gusty winds periodically blow across bridges, threatening to push Milo off ledges.

---

## 5. Enemies Introduced
- **Frost Eagles:** Swoop down from high cliffs to grab and drop Milo.
- **Ice Golems:** Heavy frost creatures that freeze the ground around them.
- **Rogue Ninja Cats:** Swift feline mercenaries hired by Kuro.

---

## 6. Boss Duel: "Kuro the Rogue Samurai"
- **Location:** The Summit Rope Bridge Plaza.
- **Description:** An agile panther cat clad in dark armor wielding twin curved katanas.
- **Reward:** Kuro hands Milo the **Celestial Sky Key**.

---

## 7. Level Ending & Reward
Milo inserts the Sky Key into the mountain altar, opening the beam portal into the floating **Sky Citadel**.
