# Notice: Level Renumbered

This level was renumbered during the expansion to an 8-level campaign.

Please see:
- **[Level 5: The Haunted Swamps & Ghost Village](file:///Users/mk/StudioProjects/bravecat/story/level5_haunted_swamps.md)**
- **[Level 8: The Celestial Garden & Sky Peak](file:///Users/mk/StudioProjects/bravecat/story/level8_celestial_garden.md)**
