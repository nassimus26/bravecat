# Notice: Level Renumbered

This level was renumbered during the expansion to an 8-level campaign. 

Please see:
- **[Level 4: The Crystal Caverns & Lava Chasms](file:///Users/mk/StudioProjects/bravecat/story/level4_crystal_caverns.md)**
- **[Level 6: The Misty Mountain Crags & Glacier Pass](file:///Users/mk/StudioProjects/bravecat/story/level6_misty_mountains.md)**
