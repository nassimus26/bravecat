# Level 2: The Whispering Jungle & Bamboo Forest

## 1. Setting & Atmosphere
- **Environment:** Dense tropical jungle filled with towering bamboo stalks, giant glowing mushrooms, rushing rivers, rickety rope bridges, and ancient moss-covered stone statues.
- **Time of Day:** Midday with sunbeams filtering through dense tree canopy.
- **Music & Audio:** Tribal drums, ambient jungle bird calls, roaring river sounds, and sharp sword swishes.

---

## 2. Narrative Scenario
Carrying Dr. Whiskerfield's pass, Milo enters the Whispering Jungle to search for the Hermit's Tree Library where the ancient texts are kept. The jungle wildlife has been corrupted by dark energy spilling down from Sky Peak.

---

## 3. Level Quest Objective: 📖 Retrieve the Ancient Botanical Tome
- **Primary Goal:** Fight through the jungle canopies and defeat the Serpent Guardian to enter the Hermit's Tree Library.
- **Key Achievement:** Milo retrieves the **Ancient Botanical Tome**.
- **Book's Secret:**
  > The book confirms that the **Celestial Blossom** can cure the Shadow Curse! However, the map showing the path to the flower is written in **invisible solar ink** that can only be read under concentrated sunlight.

---

## 4. Environment Mechanics & Hazards
- **Cutting Vines:** Thick overgrown vines block pathways. Milo must use light sword slashes to slice through them.
- **River Log Crossings:** Logs float down the roaring river; Milo must jump and time his balance across logs.
- **Spore Mushrooms:** Glowing purple mushrooms explode with poison gas if struck or stepped on.

---

## 5. Enemies Introduced
- **Venomous Vipers:** Hiding in high grass; perform quick lunging strikes.
- **Giant Jungle Spiders:** Web-shooters that temporarily slow Milo down.
- **Corrupted Wild Boars:** Heavily armored enemies that lunge straight ahead.

---

## 6. Boss Fight: "Kaa’thor the Serpent Sovereign"
- **Location:** The Great Bamboo Library Tree.
- **Description:** A massive giant green serpent whose scales glow with dark purple corruption guarding the library vault.
- **Reward:** Kaa'thor collapses, unlocking the library chest containing the **Ancient Botanical Tome**.

---

## 7. Level Ending & Reward
Milo opens the book, but the map page is blank! A marginal note says: *"Seek the Solar Lens in the Desert Catacombs to reveal the path."* Milo heads underground into the **Sunken Desert Ruins**.
