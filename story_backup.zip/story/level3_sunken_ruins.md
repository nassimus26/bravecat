# Level 3: The Sunken Desert Ruins & Catacombs

## 1. Setting & Atmosphere
- **Environment:** Deep underground stone catacombs, sandfalls, ancient feline hieroglyphics, crumbling bridges over pit traps, and flickering torch light.
- **Time of Day:** Underground Cavern / Torchlight.
- **Music & Audio:** Echoing Middle-Eastern scales, resonant percussion, crumbling stone FX, and echoing footsteps.

---

## 2. Narrative Scenario
Milo descends into the catacombs of the Ancient Cat Kings to retrieve the **Solar Crystal Lens**, an ancient artifact capable of refracting sunlight into concentrated beams to read invisible solar ink.

---

## 3. Level Quest Objective: 🔍 Retrieve the Solar Crystal Lens
- **Primary Goal:** Solve ancient hieroglyph pressure plate puzzles and defeat the Stone Golem to retrieve the Solar Crystal Lens.
- **Key Achievement:** Milo obtains the **Solar Crystal Lens** and shines torchlight through it onto the Ancient Botanical Tome!
- **Revealed Map & Warning:**
  > The invisible ink glows brightly, revealing the map to Sky Peak! It also reveals a vital warning:
  > *"CRITICAL: The Celestial Blossom will wither and lose its curative power within 1 minute of being picked UNLESS preserved inside a Thermal Crystal Flask forged in volcanic heat!"*

---

## 4. Environment Mechanics & Hazards
- **Pressure Plate Tiles:** Floor tiles with cat paw prints. Stepping on correct tiles opens doors; wrong tiles trigger dart traps.
- **Pillar Wall-Bouncing:** Narrow stone corridors requiring Milo to double-jump and bounce between walls.
- **Fire-Jet Traps:** Periodic flame streams bursting from wall statues.

---

## 5. Enemies Introduced
- **Mummified Jackals:** Undead guards wielding curved scimitars. High defense.
- **Sand Scorpion Sentinels:** Fast-moving scorpion automatons with tail stingers.
- **Shadow Phantoms:** Floating spectral entities that pass through obstacles.

---

## 6. Boss Fight: "Anubis the Obsidian Golem"
- **Location:** The Chamber of the Solar Altar.
- **Description:** A giant 15-foot stone golem guarding the Solar Crystal Lens.
- **Reward:** Anubis collapses, dropping the **Solar Crystal Lens**.

---

## 7. Level Ending & Reward
With the Solar Lens in hand, Milo reads the warning about the flower withering. To forge the required **Thermal Crystal Flask**, Milo enters the fiery depths of the **Crystal Caverns**.
