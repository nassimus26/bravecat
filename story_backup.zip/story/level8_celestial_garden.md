# Level 8: The Celestial Garden & Sky Peak

## 1. Setting & Atmosphere
- **Environment:** Majestic floating sky islands above a sea of sunset clouds, golden ancient altars, glowing ethereal cherry trees, floating crystal walkways, and the sacred altar of the Celestial Blossom.
- **Time of Day:** Eternal Celestial Twilight / Golden Hour.
- **Music & Audio:** Grand choir vocals, soaring orchestral melody, ethereal chime FX, and intense boss battle orchestration.

---

## 2. Narrative Scenario
Milo crosses the Starlight Bridge into the **Celestial Garden**. Floating in the center of the grandest altar is the glowing **Celestial Blossom**. 

As Milo steps forward, dark mist coalesces into **Umbra, The Shadow Guardian**, who vows to prevent Milo from taking the cure.

---

## 3. Level Quest Objective: 🌸 Defeat Umbra, Harvest the Blossom & Save Master Sifu
- **Primary Goal:** Defeat Umbra, pluck the Celestial Blossom, seal it in the **Thermal Crystal Flask**, and race home to prepare the cure!
- **Key Achievement:** Milo defeats Umbra, seals the flower safely, returns to the dojo, and follows Master Botan's recipe to brew the potion and **cure Master Sifu**!

---

## 4. Environment Mechanics & Hazards
- **Low-Gravity Platforming:** Extended air-time platforming across floating sky islands.
- **Collapsing Sky Runes:** Floating platforms crumble 2 seconds after being stepped on.
- **Astral Laser Beams:** Sweeping laser beams during boss phases.

---

## 5. Enemies Introduced
- **Celestial Shadow Manifestations:** Shadow energy clones of previous enemies.
- **Astral Sentinels:** Orb sentinels that cast shield barriers.

---

## 6. Final Boss Fight: "Umbra — The Shadow Guardian" (2 Phases)
- **Phase 1 (Blade Sentinel):** Towering starry knight wielding a shadowy greatsword.
- **Phase 2 (Cosmic Shadow Beast):** Dragon-like beast covering arena in dark fire. Milo deflects cosmic orbs back with sword slashes to stun Umbra and deliver the final blow.

---

## 7. Climax, Epilogue & Ending
1. **Harvesting the Flower:** Milo plucks the glowing Celestial Blossom and seals it inside the **Thermal Crystal Flask**.
2. **Returning Home:** Milo races down the mountain back to Master Sifu's Dojo.
3. **The Cure Ritual:** Using Dr. Whiskerfield's diagnosis, the Botanical Book's instructions, and Master Botan's recipe, Milo steeps 3 petals in boiled water at dawn, stirs 3 times counter-clockwise, and chants the Mantra of Light.
4. **Master Sifu Awakens:** The dark shadow mist vanishes from Master Sifu's body. He opens his eyes, completely cured! He bows deeply to Milo, acknowledging him as a true Master Cat Warrior and Savior of the Realm.

**THE END — THANK YOU FOR PLAYING!**
